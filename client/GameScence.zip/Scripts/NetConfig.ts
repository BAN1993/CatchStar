
export class NetConfig {
  public static MAX_BUFFER_SIZE = 5120
  public static MAX_OPT_SIZE = 4096

  public static serverHost: string = "ws://127.0.0.1:6001"
}
